﻿BioSPPy is written and maintained by Carlos Carreiras and
various contributors:

Development Lead
----------------

- Carlos Carreiras (<carlos.carreiras@lx.it.pt>)

Main Contributors
-----------------

- Ana Priscila Alves (<anapriscila.alves@lx.it.pt>)
- André Lourenço (<arlourenco@lx.it.pt>)
- Filipe Canento (<fcanento@lx.it.pt>)
- Hugo Silva (<hugo.silva@lx.it.pt>)

Scientific Supervision
----------------------

- Ana Fred <afred@lx.it.pt>

Patches and Suggestions
-----------------------

- Hayden Ball (PR/7)
- Jason Li (PR/13)
- Dominique Makowski (<dom.makowski@gmail.com>) (PR/15, PR/24)
- Margarida Reis (PR/17)
- Michael Gschwandtner (PR/23)
